With the following composer.json:

```json
{
    ...
}
```

When I run this command:

```
composer command -vvv (please include -vvv!)
```

I get this output:

```

```

And I expected this to happen:
