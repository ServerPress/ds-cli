<?php

namespace Installer;

use Composer\Composer;
use Composer\IO\IOInterface;
use Composer\Plugin\PluginInterface;

class Plugin7 implements PluginInterface
{
    public function activate(Composer $composer, IOInterface $io)
    {
    }
}
