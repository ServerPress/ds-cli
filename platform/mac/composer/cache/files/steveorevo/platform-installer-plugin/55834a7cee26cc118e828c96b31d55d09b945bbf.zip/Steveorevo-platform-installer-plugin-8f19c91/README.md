# platform-installer-plugin
The custom installer for enabling https://github.com/Steveorevo/platform-installer
