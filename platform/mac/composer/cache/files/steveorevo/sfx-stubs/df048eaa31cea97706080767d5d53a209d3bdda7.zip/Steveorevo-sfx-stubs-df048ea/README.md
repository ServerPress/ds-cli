# sfx-stubs
A simple library of sfx stubs for creating self-extracting archives when using the RAR cli tool.
